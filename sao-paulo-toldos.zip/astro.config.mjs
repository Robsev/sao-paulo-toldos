import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

// Site institucional em modo estático (SSG) — ideal para hospedagem
// compartilhada/VPS servindo arquivos via Nginx, sem runtime Node em produção.
//
// Site já publicado na RAIZ do domínio (o WordPress antigo foi removido).
//
// Observação: o sitemap é gerado por um endpoint estático próprio
// (src/pages/sitemap.xml.ts) em vez do pacote @astrojs/sitemap, que na
// versão atual depende de um hook do Astro (astro:routes:resolved) não
// suportado pela linha 4.x do Astro usada neste projeto.
export default defineConfig({
  site: 'https://www.saopaulotoldos.com.br',
  base: '/',
  output: 'static',
  integrations: [tailwind()],
});
