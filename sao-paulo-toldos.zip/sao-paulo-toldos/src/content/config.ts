import { defineCollection, z } from 'astro:content';

const produtos = defineCollection({
  type: 'data',
  schema: z.object({
    nome: z.string(),
    slug: z.string(),
    resumo: z.string(),
    descricao: z.string(),
    imagemCapa: z.string(),
    galeria: z.array(z.string()).default([]),
    ordem: z.number().default(0),
  }),
});

export const collections = { produtos };
