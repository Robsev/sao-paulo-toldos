// Junta um caminho absoluto (ex: "/images/foo.jpg") com o BASE_URL do Astro,
// necessário porque o site é publicado numa subpasta (ex: /sitenovo/).
export function withBase(path: string): string {
  const base = import.meta.env.BASE_URL; // ex: "/sitenovo/"
  return `${base}${path.replace(/^\//, '')}`;
}
