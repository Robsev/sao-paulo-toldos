import type { APIRoute } from 'astro';
import { getCollection } from 'astro:content';

// Sitemap gerado manualmente como endpoint estático (em vez de usar o pacote
// @astrojs/sitemap, cuja versão atual depende de um hook do Astro
// — astro:routes:resolved — não suportado pela linha 4.x do Astro usada
// neste projeto). Isso evita a dependência extra e mantém o build simples.
//
// IMPORTANTE: enquanto o site estiver em /sitenovo/ (avaliação), as URLs
// abaixo refletirão essa subpasta. Quando o site for publicado na raiz do
// domínio, troque `base` para '/' em astro.config.mjs e gere um novo build
// para que este sitemap aponte para a raiz.
export const GET: APIRoute = async ({ site }) => {
  const baseUrl = site ?? new URL('https://www.saopaulotoldos.com.br/sitenovo/');

  const paginasEstaticas = [
    '',
    'produtos/',
    'clientes/',
    'contato/',
    'controle/',
    'politica-de-privacidade/',
  ];

  const produtos = await getCollection('produtos');
  const paginasProdutos = produtos.map((produto) => `produtos/${produto.data.slug}/`);

  const caminhos = [...paginasEstaticas, ...paginasProdutos];
  const hoje = new Date().toISOString().split('T')[0];

  const urls = caminhos
    .map((caminho) => {
      const url = new URL(caminho, baseUrl).href;
      return `  <url>\n    <loc>${url}</loc>\n    <lastmod>${hoje}</lastmod>\n  </url>`;
    })
    .join('\n');

  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;

  return new Response(xml, {
    headers: { 'Content-Type': 'application/xml; charset=utf-8' },
  });
};
