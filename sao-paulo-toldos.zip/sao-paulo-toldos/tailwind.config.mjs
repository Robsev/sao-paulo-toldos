/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/**/*.{astro,html,js,jsx,md,mdx,svelte,ts,tsx,vue}'],
  theme: {
    extend: {
      colors: {
        // Paleta derivada do logo atual da São Paulo Toldos
        // (azul do texto "TOLDOS", vermelho de "SÃO PAULO", amarelo do sol).
        brand: {
          blue: '#1e3a8a',
          red: '#dc2626',
          yellow: '#facc15',
          dark: '#1c1917',
        },
      },
      fontFamily: {
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
