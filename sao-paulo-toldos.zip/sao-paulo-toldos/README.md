# São Paulo Toldos — novo site (Astro + Tailwind)

Site institucional reconstruído do zero (o atual está em WordPress/Elementor).
Gera arquivos estáticos (HTML/CSS/JS puros) — roda em qualquer hospedagem,
inclusive o VPS Hostinger já contratado, sem depender de runtime Node em produção.

## Por que este projeto não veio com `node_modules` já instalado

Este projeto foi montado em um ambiente sem acesso ao registro npm, então as
dependências não foram baixadas aqui. É só rodar `npm install` normalmente no
seu computador ou no VPS — leva menos de um minuto.

## Passo a passo para avaliar localmente

```bash
npm install
npm run dev
```

Abra http://localhost:4321 — dá pra navegar por todas as páginas
(Início, Produtos, cada categoria, Clientes, Contato) e ver o resultado real.

Para gerar a versão de produção (arquivos estáticos prontos para subir):

```bash
npm run build
```

Isso cria a pasta `dist/` — é o conteúdo que vai para o servidor.

## Estrutura do projeto

- `src/pages/` — cada página do site (rotas)
- `src/components/` — Header, Footer, Cartão de produto, Formulário
- `src/content/produtos/*.json` — catálogo de produtos (8 categorias já
  criadas com dados de exemplo; trocar textos/fotos reais depois)
- `public/images/` — onde entram as fotos reais dos produtos (hoje estão
  faltando — o site atual também tinha esse problema)
- `public/admin/` — painel de edição de conteúdo (Decap CMS), pensado
  para quem não mexe com código

## Publicar em subpasta do domínio para avaliação (sem afetar o site atual)

1. Crie um repositório no GitHub com este projeto (`git init`, `git add .`,
   `git commit`, `git push`).
2. No VPS Hostinger, crie uma subpasta separada, por exemplo
   `public_html/preview/` — ela ficará acessível em algo como
   `saopaulotoldos.com.br/preview/` sem mexer no site em produção.
3. Gere um par de chaves SSH só para o deploy automático e adicione a
   chave pública ao `~/.ssh/authorized_keys` do VPS.
4. No GitHub, vá em Settings > Secrets and variables > Actions e cadastre:
   - `VPS_HOST` — IP ou host do VPS
   - `VPS_USER` — usuário SSH
   - `VPS_SSH_KEY` — chave privada gerada no passo 3
   - `VPS_TARGET_DIR` — caminho da subpasta, ex: `/home/usuario/public_html/preview`
5. A cada `git push` na branch `main`, o GitHub Actions builda o site e
   envia automaticamente para essa subpasta via rsync/SSH
   (workflow em `.github/workflows/deploy.yml`).

Depois de aprovado, o mesmo fluxo pode apontar para a pasta raiz do
domínio (`public_html/`) para ir ao ar de vez.

## Painel de administração de conteúdo (Decap CMS)

Acessível em `/admin` depois de publicado. Antes de usar:

1. Edite `public/admin/config.yml` e troque `SEU-USUARIO/sao-paulo-toldos`
   pelo repositório real no GitHub.
2. Configure autenticação (GitHub OAuth ou Git Gateway) — posso te ajudar
   nesse passo quando chegarmos nele.

## Formulário de orçamento

Por padrão aponta para `/api/orcamento` (ainda não implementado — decidimos
deixar essa escolha para depois: endpoint próprio no VPS vs. serviço externo
gratuito como Web3Forms/Formspree). Configurável via variável de ambiente
`PUBLIC_FORM_ENDPOINT`.

## Pendências conhecidas

- Fotos reais dos produtos (hoje usando caminhos placeholder em
  `/images/produtos/<categoria>/capa.jpg`)
- Decidir e implementar o backend do formulário de orçamento
- Configurar autenticação do Decap CMS
- Trocar `/images/logo.svg` e `/images/hero.jpg` pelos arquivos reais
