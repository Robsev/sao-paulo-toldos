import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import sitemap from '@astrojs/sitemap';

// Site institucional em modo estático (SSG) — ideal para hospedagem
// compartilhada/VPS servindo arquivos via Nginx, sem runtime Node em produção.
//
// IMPORTANTE: enquanto o site estiver publicado em /sitenovo/ (avaliação),
// o sitemap gerado abaixo refletirá essa subpasta. Quando o site substituir
// o site atual na raiz do domínio, troque `base` para '/' e gere um novo build
// para que o sitemap e as URLs canônicas apontem para a raiz.
export default defineConfig({
  site: 'https://www.saopaulotoldos.com.br',
  base: '/sitenovo/',
  output: 'static',
  integrations: [tailwind(), sitemap()],
});
