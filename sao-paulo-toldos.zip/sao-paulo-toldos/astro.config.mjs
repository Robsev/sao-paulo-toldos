import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

// Site institucional em modo estático (SSG) — ideal para hospedagem
// compartilhada/VPS servindo arquivos via Nginx, sem runtime Node em produção.
export default defineConfig({
  site: 'https://www.saopaulotoldos.com.br',
  output: 'static',
  integrations: [tailwind()],
});
