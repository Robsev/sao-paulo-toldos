import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';

// Site institucional em modo estático (SSG) — ideal para hospedagem
// compartilhada/VPS servindo arquivos via Nginx, sem runtime Node em produção.
//
// IMPORTANTE: enquanto o site estiver publicado em /sitenovo/ (avaliação),
// o sitemap gerado (src/pages/sitemap.xml.ts) refletirá essa subpasta. Quando
// o site substituir o site atual na raiz do domínio, troque `base` para '/' e
// gere um novo build para que o sitemap e as URLs canônicas apontem para a raiz.
//
// Observação: o sitemap é gerado por um endpoint estático próprio
// (src/pages/sitemap.xml.ts) em vez do pacote @astrojs/sitemap, que na
// versão atual depende de um hook do Astro (astro:routes:resolved) não
// suportado pela linha 4.x do Astro usada neste projeto.
export default defineConfig({
  site: 'https://www.saopaulotoldos.com.br',
  base: '/sitenovo/',
  output: 'static',
  integrations: [tailwind()],
});
